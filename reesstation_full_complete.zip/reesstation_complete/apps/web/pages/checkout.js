export default function Checkout(){return <div className='p-4'><h1 className='text-2xl font-bold'>صفحة الدفع</h1></div>;}
