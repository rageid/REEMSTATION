import { useRouter } from 'next/router';
export default function Order() {
  const { id } = useRouter().query;
  return <div className='p-4'><h1 className='text-2xl font-bold'>تتبع الطلب {id}</h1></div>;
}
