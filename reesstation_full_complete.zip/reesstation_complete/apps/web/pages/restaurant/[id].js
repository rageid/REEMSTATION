import { useRouter } from 'next/router';
export default function Restaurant() {
  const { id } = useRouter().query;
  return <div className="p-4"><h1 className="text-2xl font-bold">تفاصيل المطعم {id}</h1></div>;
}
