export default function Cart(){return <div className='p-4'><h1 className='text-2xl font-bold'>سلة الطلبات</h1></div>;}
