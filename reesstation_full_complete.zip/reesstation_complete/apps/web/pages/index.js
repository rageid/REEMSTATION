import Link from 'next/link';
export default function Home() {
  const restaurants = [{id:'r1',name:'مطعم ألف'},{id:'r2',name:'مطعم باء'}];
  return <div className="p-4">
    <h1 className="text-2xl font-bold mb-4">مطاعم ReesStation</h1>
    <ul>{restaurants.map(r=><li key={r.id}><Link href={`/restaurant/${r.id}`} className="text-blue-600 underline">{r.name}</Link></li>)}</ul>
  </div>;
}
